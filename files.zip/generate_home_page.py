#!/usr/bin/env python3
"""
Indoor Football Index — home page generator.

Reads the 'Schedule' tab of a workbook like 2026_IFI.xlsx and builds index.html:
  - Recent games: the 10 most recently completed games before today
  - Upcoming schedule: the 10 next unplayed games from today forward
  - News: the 4 most recent articles from news.json (built separately by
    build_news_json.py from a folder of Word docs) — run that first, or
    this section will just show an empty state.

Usage:
    python3 generate_home_page.py path/to/2026_IFI.xlsx path/to/index.html [path/to/news.json]
"""

import sys
import os
import re
import json
import datetime
import openpyxl


SEARCH_JS = r"""
(function(){
  var SEARCH_INDEX = null;
  function loadIndex(){
    if (SEARCH_INDEX) return Promise.resolve(SEARCH_INDEX);
    return fetch('search-index.json').then(function(r){ return r.json(); }).then(function(data){ SEARCH_INDEX = data; return data; });
  }
  function escSearch(s){
    var d = document.createElement('div');
    d.textContent = s == null ? '' : s;
    return d.innerHTML;
  }
  function resultRow(item){
    return '<a class="search-result-row" href="' + item.href + '">' +
      '<div><div class="sr-name">' + escSearch(item.name) + '</div>' + (item.meta ? '<div class="sr-meta">' + escSearch(item.meta) + '</div>' : '') + '</div>' +
      '<span class="sr-type">' + item.type + '</span>' +
    '</a>';
  }
  function doSearch(query, resultsEl){
    if (!query){ resultsEl.innerHTML=''; resultsEl.classList.remove('open'); return; }
    loadIndex().then(function(data){
      var q = query.toLowerCase();
      var matches = data.filter(function(item){ return item.name.toLowerCase().indexOf(q) !== -1; }).slice(0, 20);
      if (!matches.length){
        resultsEl.innerHTML = '<div class="search-empty">No results for &ldquo;' + escSearch(query) + '&rdquo;</div>';
      } else {
        resultsEl.innerHTML = matches.map(resultRow).join('');
      }
      resultsEl.classList.add('open');
    }).catch(function(){
      resultsEl.innerHTML = '<div class="search-empty">Search unavailable.</div>';
      resultsEl.classList.add('open');
    });
  }

  var searchBtn = document.getElementById('searchBtn');
  var overlay = document.getElementById('searchOverlay');
  var desktopInput = document.getElementById('desktopSearchInput');
  var desktopResults = document.getElementById('desktopSearchResults');
  var closeBtn = document.getElementById('searchCloseBtn');

  if (searchBtn && overlay){
    searchBtn.addEventListener('click', function(){
      overlay.classList.add('open');
      desktopInput.value = '';
      desktopResults.innerHTML = '';
      desktopResults.classList.remove('open');
      setTimeout(function(){ desktopInput.focus(); }, 50);
    });
    function closeOverlay(){ overlay.classList.remove('open'); }
    closeBtn.addEventListener('click', closeOverlay);
    overlay.addEventListener('click', function(e){ if (e.target === overlay) closeOverlay(); });
    document.addEventListener('keydown', function(e){ if (e.key === 'Escape') closeOverlay(); });
    desktopInput.addEventListener('input', function(){ doSearch(this.value.trim(), desktopResults); });
  }

  var mobileInput = document.getElementById('mobileSearchInput');
  var mobileResults = document.getElementById('mobileSearchResults');
  if (mobileInput && mobileResults){
    mobileInput.addEventListener('input', function(){ doSearch(this.value.trim(), mobileResults); });
    document.addEventListener('click', function(e){
      if (!mobileInput.contains(e.target) && !mobileResults.contains(e.target)){
        mobileResults.classList.remove('open');
      }
    });
  }
})();
"""


def esc(s):
    if s is None:
        return ""
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def fmt_score(v):
    if v is None:
        return ""
    if isinstance(v, float) and v == int(v):
        v = int(v)
    return esc(v)


def load_schedule(xlsx_path):
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb["Schedule"]
    rows = list(ws.iter_rows(values_only=True))
    headers = rows[0]
    idx = {h: i for i, h in enumerate(headers) if h is not None}
    games = []
    for r in rows[1:]:
        date = r[idx["Date"]]
        if date is None:
            continue
        home = r[idx["Home Team"]]
        away = r[idx["Away Team"]]
        if not home or not away:
            continue
        home_score = r[idx["Home Score"]] if "Home Score" in idx else None
        away_score = r[idx["Away Score"]] if "Away Score" in idx else None
        week = r[idx["Week"]] if "Week" in idx else None
        week_low = str(week).lower()
        is_championship = "championship" in week_low
        is_playoff = is_championship or any(k in week_low for k in ("playoff", "semifinal", "quarterfinal"))
        games.append({
            "date": date,
            "dow": r[idx["Day of the Week"]] if "Day of the Week" in idx else None,
            "home": home,
            "away": away,
            "time": r[idx["Time (CST)"]] if "Time (CST)" in idx else None,
            "week": week,
            "league": r[idx["League"]] if "League" in idx else None,
            "watch": r[idx["Watch"]] if "Watch" in idx else None,
            "home_score": home_score,
            "away_score": away_score,
            "played": home_score is not None and away_score is not None,
            "playoff": is_playoff,
            "championship": is_championship,
        })
    return games


def load_team_logos(xlsx_path):
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    if "All Teams" not in wb.sheetnames:
        return {}
    ws = wb["All Teams"]
    rows = list(ws.iter_rows(values_only=True))
    headers = rows[0]
    idx = {h: i for i, h in enumerate(headers) if h is not None}
    if "Team Name" not in idx or "Logo" not in idx:
        return {}
    logos = {}
    for r in rows[1:]:
        name = r[idx["Team Name"]]
        logo = r[idx["Logo"]]
        if name and logo:
            logos[name] = logo
    return logos


def team_block(name, score, other_score, played, logos):
    logo_url = logos.get(name)
    logo_html = f'<img src="{esc(logo_url)}" alt="{esc(name)} logo" onerror="this.style.display=\'none\'">' if logo_url else ""
    cls = "team-block"
    if played and score is not None and other_score is not None:
        cls += " winner" if score > other_score else " loser"
    score_html = f'<div class="score">{fmt_score(score)}</div>' if played and score is not None else ""
    return f'<div class="{cls}"><div class="logo">{logo_html}</div><div class="name">{esc(name)}</div>{score_html}</div>'


def game_card(g, logos):
    date_label = g["date"].strftime("%b %-d, %Y" if sys.platform != "win32" else "%b %#d, %Y")
    dow = f' &middot; {esc(g["dow"])}' if g["dow"] else ""
    league = esc(g["league"]) if g["league"] else ""
    card_cls = "game-card playoff" if g["playoff"] else "game-card"
    status_html = '<div class="game-status">Final</div>' if g["played"] else \
        f'<div class="game-status live-time">{esc(g["time"]) if g["time"] else "Time TBD"}</div>'
    watch_html = f'<a class="watch-btn" href="{esc(g["watch"])}" target="_blank" rel="noopener">Watch</a>' if g.get("watch") else "<span></span>"
    week_label = "Championship" if g["championship"] else (esc(g["week"]) if g["week"] else "")
    return f'''    <div class="{card_cls}">
      <div class="game-card-head"><span class="date">{date_label}{dow}</span><span class="league">{league}</span></div>
      {status_html}
      <div class="matchup">{team_block(g["away"], g["away_score"], g["home_score"], g["played"], logos)}<span class="vs-sep">@</span>{team_block(g["home"], g["home_score"], g["away_score"], g["played"], logos)}</div>
      <div class="game-card-foot">{watch_html}<span class="week-label">{week_label}</span></div>
    </div>'''


def load_news(news_json_path):
    if not news_json_path or not os.path.isfile(news_json_path):
        return []
    with open(news_json_path, encoding="utf-8") as f:
        return json.load(f)


def strip_tags(html):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html or "")).strip()


def build_news_html(articles):
    if not articles:
        return ('  <div class="tba-strip"><div class="big">No news articles yet.</div>'
                '<div class="small">Run build_news_json.py against a folder of Word docs to populate this.</div></div>')
    cards = []
    for item in articles[:4]:
        cls = "news-card feature" if item.get("featured") else "news-card"
        excerpt_len = 260 if item.get("featured") else 160
        excerpt = strip_tags(item.get("body"))
        if len(excerpt) > excerpt_len:
            excerpt = excerpt[:excerpt_len].strip() + "\u2026"
        kicker_html = f'<div class="kicker">{esc(item["kicker"])}</div>' if item.get("kicker") else ""
        cards.append(
            f'    <a class="{cls}" href="article.html?article={esc(item["slug"])}">\n'
            f'      {kicker_html}\n'
            f'      <h3>{esc(item["title"])}</h3>\n'
            f'      <p>{esc(excerpt)}</p>\n'
            f'      <div class="date">{esc(item.get("date", ""))}</div>\n'
            f'    </a>'
        )
    return '  <div class="news-grid">\n' + "\n".join(cards) + "\n  </div>"


TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Indoor Football Index</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Anton&family=IBM+Plex+Mono:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>

  :root{{
    --arena-black:#111316;
    --arena-black-2:#1a1d21;
    --accent-green:#19FF00;
    --amber:#E8A33D;
    --turf:#3C6E47;
    --chalk:#F2EFE6;
    --chalk-dim:#c9c6bc;
    --steel:#82868c;
    --steel-line:#2a2d31;
    --card:#1c1f23;
    --card-line:#2e3136;
  }}

  *{{box-sizing:border-box;}}
  html{{scroll-behavior:smooth;}}
  body{{
    margin:0;
    background:var(--arena-black);
    color:var(--chalk);
    font-family:'Inter',system-ui,sans-serif;
    -webkit-font-smoothing:antialiased;
  }}

  .display{{font-family:'Anton',sans-serif; text-transform:uppercase; letter-spacing:0.01em;}}
  .mono{{font-family:'IBM Plex Mono',monospace;}}
  a{{color:inherit; text-decoration:none;}}

  .hashes{{width:100%; height:14px; display:flex; align-items:center;}}
  .hashes svg{{width:100%; height:100%; display:block;}}

  .topbar{{
    width:100%; background:var(--card); border-bottom:1px solid var(--card-line);
    position:sticky; top:0; z-index:100;
  }}
  .topbar-inner{{display:flex; align-items:center; justify-content:space-between; max-width:1400px; margin:0 auto; padding:16px 32px; gap:20px;}}
  .topbar .site{{font-size:13px; letter-spacing:0.14em; text-transform:uppercase; color:var(--steel); white-space:nowrap; display:flex; align-items:center; gap:10px;}}
  .topbar .site strong{{color:var(--chalk); font-weight:600;}}
  .topbar .site .crumb{{color:var(--steel);}}
  .nav-desktop{{display:flex; gap:22px; font-size:12px; letter-spacing:0.05em; text-transform:uppercase; color:var(--steel); flex-wrap:wrap;}}
  .nav-desktop a:hover{{color:var(--chalk);}}
  .hamburger-btn{{display:none; background:none; border:none; color:var(--chalk); font-size:20px; line-height:1; cursor:pointer; padding:2px 4px; flex-shrink:0;}}
  .mobile-menu{{display:none; flex-direction:column; background:var(--card); border-bottom:1px solid var(--card-line); padding:6px 24px 14px;}}
  .mobile-menu.open{{display:flex;}}
  .mobile-menu a{{padding:11px 0; font-size:13px; color:var(--chalk-dim); border-bottom:1px solid var(--steel-line); text-transform:uppercase; letter-spacing:0.05em;}}
  .mobile-menu a:last-child{{border-bottom:none;}}
  @media (max-width:860px){{
    .nav-desktop{{display:none;}}
    .hamburger-btn{{display:block;}}
    .topbar-inner{{padding:14px 16px; gap:10px; flex-wrap:wrap;}}
    .topbar .site{{font-size:11px;}}
    .topbar .site .crumb{{display:none;}}
  }}

  .hero{{max-width:1160px; margin:0 auto; padding:64px 24px 44px;}}
  .hero .eyebrow{{
    font-size:12px; letter-spacing:0.2em; text-transform:uppercase; color:var(--accent-green);
    font-weight:600; margin:0 0 14px;
  }}
  .hero h1{{font-size:clamp(44px,7vw,84px); line-height:0.92; margin:0 0 18px; color:var(--chalk);}}
  .hero p{{font-size:16px; color:var(--steel); max-width:560px; line-height:1.7; margin:0 0 26px;}}
  .hero .cta{{
    display:inline-flex; align-items:center; gap:8px; background:var(--accent-green); color:#072237;
    font-size:14px; font-weight:600; padding:13px 22px; border-radius:8px;
  }}
  .hero .cta:hover{{background:#b81f31;}}

  section{{max-width:1160px; margin:0 auto; padding:48px 24px;}}
  .section-head{{display:flex; align-items:baseline; justify-content:space-between; margin-bottom:22px; gap:16px; flex-wrap:wrap;}}
  .section-head h2{{font-size:24px; margin:0; color:var(--chalk);}}
  .section-head .note{{font-size:13px; color:var(--steel);}}

  .game-grid{{display:grid; grid-template-columns:repeat(3,1fr); gap:14px;}}
  @media (max-width:900px){{.game-grid{{grid-template-columns:repeat(2,1fr);}}}}
  @media (max-width:600px){{.game-grid{{grid-template-columns:1fr;}}}}

  .game-card{{background:var(--card); border:1px solid var(--card-line); border-radius:12px; padding:16px;}}
  .game-card.playoff{{border-color:rgba(232,163,61,0.35);}}
  .game-card-head{{display:flex; justify-content:space-between; align-items:baseline; margin-bottom:10px;}}
  .game-card-head .date{{font-size:12px; color:var(--chalk-dim);}}
  .game-card-head .league{{font-size:11px; color:var(--amber); font-family:'IBM Plex Mono',monospace;}}
  .game-status{{text-align:center; font-size:11px; letter-spacing:0.1em; text-transform:uppercase; color:var(--steel); margin-bottom:10px;}}
  .game-status.live-time{{color:var(--turf);}}
  .matchup{{display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:12px;}}
  .team-block{{flex:1; text-align:center; min-width:0;}}
  .team-block .logo{{width:44px; height:44px; margin:0 auto 8px; border-radius:8px; background:var(--arena-black-2); display:flex; align-items:center; justify-content:center; overflow:hidden;}}
  .team-block .logo img{{width:100%; height:100%; object-fit:contain; padding:5px;}}
  .team-block .name{{font-size:12px; color:var(--chalk); font-weight:600; line-height:1.3;}}
  .team-block .score{{font-size:22px; color:var(--amber); font-family:'IBM Plex Mono',monospace; margin-top:6px;}}
  .team-block.loser .score{{color:var(--steel);}}
  .vs-sep{{font-size:11px; color:var(--steel); flex-shrink:0;}}
  .game-card-foot{{display:flex; justify-content:space-between; align-items:center; gap:8px;}}
  .watch-btn{{
    font-size:11px; padding:6px 12px; border-radius:6px; background:var(--arena-black-2); color:var(--chalk-dim);
    border:1px solid var(--card-line); font-weight:600; text-decoration:none;
  }}
  .watch-btn:hover{{color:var(--chalk); border-color:var(--steel);}}
  .week-label{{font-size:11px; color:var(--steel); margin-left:auto;}}

  .tba-strip{{
    border:1px dashed var(--card-line); border-radius:10px; padding:28px 24px; text-align:center;
  }}
  .tba-strip .big{{font-size:15px; color:var(--chalk-dim); margin-bottom:6px;}}
  .tba-strip .small{{font-size:13px; color:var(--steel);}}

  .news-grid{{display:grid; grid-template-columns:1.3fr 1fr 1fr; gap:16px;}}
  .news-card{{
    background:var(--card); border:1px solid var(--card-line); border-radius:10px;
    padding:22px; display:flex; flex-direction:column; gap:10px; transition:border-color .15s;
  }}
  .news-card:hover{{border-color:var(--accent-green);}}
  .news-card.feature{{grid-row:span 2; padding:28px;}}
  .news-card .kicker{{font-size:11px; letter-spacing:0.1em; text-transform:uppercase; color:var(--accent-green); font-weight:600;}}
  .news-card h3{{font-size:18px; margin:0; color:var(--chalk); line-height:1.35;}}
  .news-card.feature h3{{font-size:26px;}}
  .news-card p{{font-size:14px; color:var(--chalk-dim); line-height:1.65; margin:0; flex:1;}}
  .news-card .date{{font-size:12px; color:var(--steel); font-family:'IBM Plex Mono',monospace; margin-top:auto;}}
  @media (max-width:900px){{
    .news-grid{{grid-template-columns:1fr 1fr;}}
    .news-card.feature{{grid-row:span 1; grid-column:span 2;}}
  }}
  @media (max-width:600px){{
    .news-grid{{grid-template-columns:1fr;}}
    .news-card.feature{{grid-column:span 1;}}
  }}

  footer{{
    max-width:1160px; margin:0 auto; padding:40px 24px 60px; display:flex; justify-content:space-between;
    flex-wrap:wrap; gap:12px; font-size:12px; color:var(--steel);
  }}

  .search-btn{{background:none; border:none; color:var(--chalk); font-size:17px; cursor:pointer; padding:4px 6px; flex-shrink:0; margin-left:4px;}}
  .search-btn:hover{{color:var(--amber);}}
  .search-overlay{{
    display:none; position:fixed; inset:0; background:rgba(8,9,10,0.75); z-index:300;
    padding-top:80px; justify-content:center;
  }}
  .search-overlay.open{{display:flex;}}
  .search-panel{{width:100%; max-width:560px; margin:0 20px;}}
  .search-panel .search-input-row{{position:relative;}}
  .search-panel input{{
    width:100%; background:var(--card); border:1px solid var(--card-line); border-radius:10px;
    color:var(--chalk); padding:15px 44px 15px 44px; font-size:16px; font-family:'Inter',sans-serif;
  }}
  .search-panel input:focus{{outline:1px solid var(--accent-green); border-color:var(--accent-green);}}
  .search-panel input::placeholder{{color:var(--steel);}}
  .search-panel .icon{{position:absolute; left:16px; top:50%; transform:translateY(-50%); color:var(--steel); font-size:16px;}}
  .search-panel .close-btn{{position:absolute; right:12px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--steel); font-size:20px; cursor:pointer; padding:4px;}}
  .search-panel .close-btn:hover{{color:var(--chalk);}}
  .search-results{{margin-top:10px; background:var(--card); border:1px solid var(--card-line); border-radius:10px; max-height:60vh; overflow-y:auto; display:none;}}
  .search-results.open{{display:block;}}
  .search-result-row{{
    display:flex; justify-content:space-between; align-items:center; gap:12px; padding:12px 16px;
    border-bottom:1px solid var(--steel-line); text-decoration:none; color:inherit;
  }}
  .search-result-row:last-child{{border-bottom:none;}}
  .search-result-row:hover{{background:rgba(255,255,255,0.03);}}
  .search-result-row .sr-name{{font-size:14px; color:var(--chalk); font-weight:600;}}
  .search-result-row .sr-meta{{font-size:12px; color:var(--steel); margin-top:2px;}}
  .search-result-row .sr-type{{
    font-size:10px; letter-spacing:0.06em; text-transform:uppercase; color:var(--amber);
    background:rgba(232,163,61,0.12); padding:3px 8px; border-radius:4px; flex-shrink:0; font-weight:600;
  }}
  .search-empty{{padding:24px; text-align:center; color:var(--steel); font-size:13px;}}

  .mobile-search-bar{{display:none;}}
  @media (max-width:860px){{
    .search-btn{{display:none;}}
    .mobile-search-bar{{display:block; flex:1; position:relative; min-width:0;}}
    .mobile-search-bar input{{
      width:100%; background:var(--arena-black-2); border:1px solid var(--card-line); border-radius:8px;
      color:var(--chalk); padding:8px 12px 8px 30px; font-size:12px; font-family:'Inter',sans-serif;
    }}
    .mobile-search-bar input::placeholder{{color:var(--steel);}}
    .mobile-search-bar .icon{{position:absolute; left:9px; top:50%; transform:translateY(-50%); color:var(--steel); font-size:12px;}}
    .mobile-search-bar .search-results{{position:absolute; top:calc(100% + 6px); left:0; right:0; width:auto; margin:0; max-height:50vh; z-index:250;}}
  }}
  ::selection{{background:var(--accent-green); color:#072237;}}
</style>
</head>
<body>

<div class="topbar">
  <div class="topbar-inner">
    <div class="site"><a href="index.html"><svg viewBox="0 0 100 56" xmlns="http://www.w3.org/2000/svg" style="width:34px; height:auto;">
        <path d="M10 28 Q26 6 50 6 Q74 6 90 28 Q74 50 50 50 Q26 50 10 28 Z" fill="#E1E5E8"/>
        <path d="M10 28 Q17 19 17 28 Q17 37 10 28 Z" fill="#9D9D9D"/>
        <path d="M90 28 Q83 19 83 28 Q83 37 90 28 Z" fill="#9D9D9D"/>
        <line x1="33" y1="28" x2="67" y2="28" stroke="#072237" stroke-width="3" stroke-linecap="round"/>
        <line x1="39" y1="21" x2="39" y2="35" stroke="#072237" stroke-width="2.5" stroke-linecap="round"/>
        <line x1="45" y1="21" x2="45" y2="35" stroke="#072237" stroke-width="2.5" stroke-linecap="round"/>
        <line x1="50" y1="21" x2="50" y2="35" stroke="#072237" stroke-width="2.5" stroke-linecap="round"/>
        <line x1="55" y1="21" x2="55" y2="35" stroke="#072237" stroke-width="2.5" stroke-linecap="round"/>
        <line x1="61" y1="21" x2="61" y2="35" stroke="#072237" stroke-width="2.5" stroke-linecap="round"/>
      </svg></a></div>
    <div class="mobile-search-bar">
      <span class="icon">&#128269;</span>
      <input type="text" id="mobileSearchInput" placeholder="Search&hellip;">
      <div class="search-results" id="mobileSearchResults"></div>
    </div>
    <nav class="nav-desktop">
      <a href="leagues.html">Leagues</a>
      <a href="teams.html">Teams</a>
      <a href="standings.html">Standings</a>
      <a href="players.html">Players</a>
      <a href="stats.html">Stats</a>
      <a href="records.html">Records</a>
      <a href="awards.html">Awards</a>
      <a href="coaches.html">Coaches</a>
      <a href="schedule.html">Schedule</a>
      <a href="scorigami.html">Scorigami</a>
      <a href="news.html">News</a>
    </nav>
    <button class="search-btn" id="searchBtn" aria-label="Search">&#128269;</button>
    <button class="hamburger-btn" id="hamburgerBtn" aria-label="Open menu">&#9776;</button>
  </div>
  <div class="mobile-menu" id="mobileMenu">
    <a href="leagues.html">Leagues</a>
    <a href="teams.html">Teams</a>
    <a href="standings.html">Standings</a>
    <a href="players.html">Players</a>
    <a href="stats.html">Stats</a>
    <a href="records.html">Records</a>
    <a href="awards.html">Awards</a>
    <a href="coaches.html">Coaches</a>
    <a href="schedule.html">Schedule</a>
    <a href="scorigami.html">Scorigami</a>
    <a href="news.html">News</a>
  </div>
</div>

<div class="search-overlay" id="searchOverlay">
  <div class="search-panel">
    <div class="search-input-row">
      <span class="icon">&#128269;</span>
      <input type="text" id="desktopSearchInput" placeholder="Search teams, players, leagues, coaches&hellip;">
      <button class="close-btn" id="searchCloseBtn" aria-label="Close">&times;</button>
    </div>
    <div class="search-results" id="desktopSearchResults"></div>
  </div>
</div>

<script>
  (function(){{
    var btn = document.getElementById('hamburgerBtn');
    var menu = document.getElementById('mobileMenu');
    if (btn && menu){{
      btn.addEventListener('click', function(){{ menu.classList.toggle('open'); }});
    }}
  }})();
</script>

{search_js}
<header class="hero">
  <p class="eyebrow">Indoor &amp; arena football, archived</p>
  <h1 class="display">Every team.<br>Every season.<br>One index.</h1>
  <p>Franchise histories, record books, and box scores for indoor and arena football &mdash; built from the ground up, one team at a time.</p>
  <a class="cta" href="teams.html">Browse teams &rarr;</a>
</header>

<div class="hashes"><svg preserveAspectRatio="none" viewBox="0 0 1160 14"><line x1="0" y1="7" x2="1160" y2="7" stroke="#2a2d31" stroke-width="1"/></svg></div>

<section id="schedule">
  <div class="section-head">
    <h2 class="display">Upcoming schedule</h2>
    <p class="note">The next {upcoming_count} games across every league in the archive.</p>
  </div>
{upcoming_html}
</section>

<div class="hashes"><svg preserveAspectRatio="none" viewBox="0 0 1160 14"><line x1="0" y1="7" x2="1160" y2="7" stroke="#2a2d31" stroke-width="1"/></svg></div>

<section id="recent">
  <div class="section-head">
    <h2 class="display">Recent games</h2>
    <p class="note">The last {recent_count} completed games across every league in the archive.</p>
  </div>
{recent_html}
</section>

<div class="hashes"><svg preserveAspectRatio="none" viewBox="0 0 1160 14"><line x1="0" y1="7" x2="1160" y2="7" stroke="#2a2d31" stroke-width="1"/></svg></div>

<section id="news">
  <div class="section-head">
    <h2 class="display">News</h2>
    <p class="note"><a href="news.html" style="color:var(--accent-green); text-decoration:underline;">See all news &rarr;</a></p>
  </div>
{news_html}
</section>

<footer>
  <span>Indoor Football Index &middot; Team histories, records, and box scores.</span>
  <span>Data compiled from IFL box scores and franchise archives.</span>
</footer>

</body>
</html>
"""


def generate(xlsx_path, out_path, news_json_path=None):
    games = load_schedule(xlsx_path)
    logos = load_team_logos(xlsx_path)
    today = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)

    completed = [g for g in games if g["played"] and g["date"] <= today]
    completed.sort(key=lambda g: g["date"], reverse=True)
    recent = completed[:10]

    upcoming = [g for g in games if not g["played"] and g["date"] >= today]
    upcoming.sort(key=lambda g: g["date"])
    upcoming = upcoming[:10]

    if recent:
        recent_html = '  <div class="game-grid">\n' + "\n".join(game_card(g, logos) for g in recent) + "\n  </div>"
    else:
        recent_html = ('  <div class="tba-strip"><div class="big">No completed games found before today.'
                        '</div><div class="small">Check that the Schedule tab has scores filled in.</div></div>')

    if upcoming:
        upcoming_html = '  <div class="game-grid">\n' + "\n".join(game_card(g, logos) for g in upcoming) + "\n  </div>"
    else:
        upcoming_html = ('  <div class="tba-strip"><div class="big">No upcoming games found.</div>'
                          '<div class="small">Check that the Schedule tab has future dates without scores.</div></div>')

    articles = load_news(news_json_path or os.path.join(os.path.dirname(os.path.abspath(out_path)), "news.json"))

    html = TEMPLATE.format(
        upcoming_count=len(upcoming),
        recent_count=len(recent),
        upcoming_html=upcoming_html,
        recent_html=recent_html,
        news_html=build_news_html(articles),
        search_js=f"<script>\n{SEARCH_JS}</script>",
    )

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Wrote {out_path} ({len(recent)} recent, {len(upcoming)} upcoming, {len(articles)} news articles)")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4):
        print("Usage: python3 generate_home_page.py <2026_IFI.xlsx> <output.html> [news.json]")
        sys.exit(1)
    news_arg = sys.argv[3] if len(sys.argv) == 4 else None
    generate(sys.argv[1], sys.argv[2], news_arg)
